class ProductCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    // Get product data
    const title = this.getAttribute("data-title") || "No Title";
    const imageSrc = this.getAttribute("data-image") || "";
    const productUrl = this.getAttribute("data-url") || "#"; // Product detail URL
    const variantsData = this.getAttribute("data-variants");

    let variants = [];
    if (variantsData) {
      try {
        variants = JSON.parse(`[${variantsData}]`);
      } catch (error) {
        console.error("Error parsing variants:", error);
      }
    }

    // Set default price (no compare price)
    let defaultPrice = variants.length > 0 ? variants[0].price : "$0.00";
    let defaultVariantId = variants.length > 0 ? variants[0].id : null;

    // HTML structure
    this.shadowRoot.innerHTML = `
      <style>
        .card {
          position: relative;
          overflow: hidden;
          background: #fff;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
          font-family: Arial, sans-serif;
          transition: 0.3s;
        }
        .card:hover {
          transform: translateY(-5px);
          box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }
        .card img {
          width: 100%;
          border-radius: 5px;
          display: block;
        }
        .card h2 {
          font-size: 16px;
          margin: 12px 0 0;
          color: #333;
          cursor: pointer;
        }
        .card h2 a {
          text-decoration: none;
          color: #333;
        }
        .price-container {
          display: flex;
          gap: 8px;
          align-items: center;
        }
        .price {
          font-size: 14px;
          color: #333;
          margin: 5px 0;
        }
        .variant-selector {
          margin-top: 10px;
          padding: 8px;
          border: 1px solid #ccc;
          border-radius: 4px;
          font-size: 14px;
          width: 100%;
        }
        .detail-wrapper {
          padding: 0 15px 15px;
        }
        .add-to-cart {
          background: #c7c7c7;
          color: white;
          border: none;
          padding: 12px;
          cursor: pointer;
          font-size: 14px;
          width: 100%;
          display: block;
          transition: 0.3s;
          opacity: 0;
          visibility: hidden;
          position: absolute;
          top: -45px;
        }
        .add-to-cart:hover {
          background: rgb(166, 163, 163);
        }
        .card:hover .add-to-cart {
          opacity: 1;
          visibility: visible;
        }
        .detail-container {
          position: relative;
        }
      </style>
      <div class="card">
        <img src="${imageSrc}" alt="${title}">
        <div class="detail-container">
          <div class="detail-wrapper">
            <h2><a href="${productUrl}">${title}</a></h2>
            <div class="price-container">
              <p class="price" id="product-price">${defaultPrice}</p>
            </div>
            ${variants.length > 1 ? `
              <select class="variant-selector">
                ${variants.map(variant => `
                  <option value="${variant.id}" data-price="${variant.price}">
                    ${variant.title}
                  </option>
                `).join('')}
              </select>
            ` : ''}
          </div>
          <button class="add-to-cart">Add to Cart</button>
        </div>
      </div>
    `;

    // Handle variant selection
    const variantSelector = this.shadowRoot.querySelector(".variant-selector");
    const priceElement = this.shadowRoot.querySelector("#product-price");

    let selectedVariantId = defaultVariantId;

    if (variantSelector) {
      variantSelector.addEventListener("change", (event) => {
        const selectedOption = event.target.selectedOptions[0];
        priceElement.textContent = selectedOption.getAttribute("data-price");
        selectedVariantId = selectedOption.value;
      });
    }

    // Add to cart functionality
    this.shadowRoot.querySelector(".add-to-cart").addEventListener("click", () => {
      alert(`${title} (Variant ID: ${selectedVariantId}) added to cart!`);
    });
  }
}

// Register the component
customElements.define("product-card", ProductCard);