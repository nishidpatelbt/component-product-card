import 'vite/modulepreload-polyfill'
import "../web/product-card/scripts/main.js";